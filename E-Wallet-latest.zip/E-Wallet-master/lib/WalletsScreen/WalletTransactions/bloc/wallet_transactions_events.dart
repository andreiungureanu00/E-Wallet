
abstract class WalletTransactionsEvents extends Object {
  const WalletTransactionsEvents();
}

class LoadWalletTransactions extends WalletTransactionsEvents {}
class ReloadWalletTransactions extends WalletTransactionsEvents {}