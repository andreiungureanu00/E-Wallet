import 'package:e_wallet/models/coin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';

class CoinsPage extends StatefulWidget {
  @override
  _CoinsPageState createState() => _CoinsPageState();
}

class _CoinsPageState extends State<CoinsPage> {
  List<Coin> coins;

  Future<List<Coin>> getCoins() async {
    Response response;
    coins = List();
    Dio dio = new Dio();
    response =
    await dio.get("http://59b689f05d7c.ngrok.io/banks/coin/?format=json");

    for (var i in response.data["results"]) {
      Coin coin =
      Coin(i["id"], i["name"], i["abbr"], i["bank"], null, null);
      coins.add(coin);
    }

    return coins;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: <Widget>[
            FutureBuilder(
              future: getCoins(),
              builder: (BuildContext context, AsyncSnapshot snapShot) {
                if (snapShot.data == null) {
                  return Align(
                    alignment: Alignment.topCenter,
                    child: CircularProgressIndicator(),
                  );
                } else {
                  return Expanded(
                    child: SizedBox(
                      height: 200.0,
                      child: new ListView.builder(
                        itemCount: snapShot.data.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                            child: Column(
                              children: <Widget>[
                                Card(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          Color(0xFFe67e22),
                                          Color(0xFFf1c40f),
                                          Colors.deepOrange,
                                        ],
                                      ),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: Column(
                                      children: [
                                        Container(
                                          height: 35,
                                          width: 400,
                                          margin: EdgeInsets.only(top: 10),
                                          child: Center(
                                            child: Text(
                                              snapShot
                                                  .data[index].name,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 17,
                                                fontFamily: 'RobotMono',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: 35,
                                          width: 400,
                                          child: Center(
                                            child: Text(
                                              snapShot.data[index].abbr,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 12,
                                                fontFamily: 'RobotMono',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: 35,
                                          width: 400,
                                          margin: EdgeInsets.only(top: 10),
                                          child: Center(
                                            child: Text(
                                              snapShot.data[index].bank.toString(),
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 12,
                                                fontFamily: 'RobotMono',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 2),
                                  ),
                                )
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
