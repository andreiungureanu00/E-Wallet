import 'package:e_wallet/BankPageScreen/bank_page_screen.dart';
import 'package:e_wallet/CoinsPage/coins_page.dart';
import 'package:e_wallet/RatesPage/rates_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Choose a category"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            RaisedButton(
              child: Text("Banks"),
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => BankPage()
                ));
              },
            ),
            RaisedButton(
              child: Text("Coins"),
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => CoinsPage()
                ));
              },
            ),
            RaisedButton(
              child: Text("Rates"),
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (context) => RatesPage()
                ));
              },
            )
          ],
        ),
      )
    );
  }

}