
abstract class TransactionCreateEvents extends Object {
  const TransactionCreateEvents();
}

class CreateTransaction extends TransactionCreateEvents {}
class ReloadTransaction extends TransactionCreateEvents {}