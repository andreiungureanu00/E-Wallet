
abstract class WalletCreateEvents extends Object {
  const WalletCreateEvents();
}

class CreateWallet extends WalletCreateEvents {}
class ReloadWallet extends WalletCreateEvents {}