import 'package:e_wallet/CurrentUserSingleton/current_user_singleton.dart';

class StringConfigs{
  static const String baseApiUrl = "https://live.curs-valutar.xyz";
}