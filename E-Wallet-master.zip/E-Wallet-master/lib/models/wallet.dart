class Wallet {
  int id;
  int user;
  int currency;
  String balance;

  // ignore: non_constant_identifier_names
  String value_buy;
  // ignore: non_constant_identifier_names
  String value_sell;
  String profit;

  Wallet(this.id, this.user, this.currency, this.balance, this.value_buy,
      this.value_sell, this.profit);

  Wallet.fromJson(Map<String, dynamic> json)
      : id = json['id'],
        user = json['user'],
        currency = json['currency'],
        balance = json['balance'],
        value_buy = json['value_buy'],
        value_sell = json['value_sell'],
        profit = json['profit'];

  Map<String, dynamic> toJson() => {
        'id': id,
        'user': user,
        'currency': currency,
        'balance': balance,
        'value_buy': value_buy,
        'value_sell': value_sell,
        'profit': profit,
      };
}
