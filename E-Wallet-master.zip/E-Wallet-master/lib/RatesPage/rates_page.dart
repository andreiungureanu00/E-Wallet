import 'package:e_wallet/models/rate.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';

class RatesPage extends StatefulWidget {
  @override
  _RatesPageState createState() => _RatesPageState();
}

class _RatesPageState extends State<RatesPage> {
  List<Rate> rates;

  Future<List<Rate>> getRates() async {
    Response response;
    rates = List();
    Dio dio = new Dio();
    response =
    await dio.get("http://59b689f05d7c.ngrok.io/banks/rate/?format=json");

    for (var i in response.data["results"]) {
      Rate rate =
      Rate(i["id"], i["rate_sell"], i["rate_buy"], i["date"], i["currency"]);
      rates.add(rate);
    }

    return rates;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: <Widget>[
            FutureBuilder(
              future: getRates(),
              builder: (BuildContext context, AsyncSnapshot snapShot) {
                if (snapShot.data == null) {
                  return Align(
                    alignment: Alignment.topCenter,
                    child: CircularProgressIndicator(),
                  );
                } else {
                  return Expanded(
                    child: SizedBox(
                      height: 200.0,
                      child: new ListView.builder(
                        itemCount: snapShot.data.length,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                            child: Column(
                              children: <Widget>[
                                Card(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          Color(0xFFe67e22),
                                          Color(0xFFf1c40f),
                                          Colors.deepOrange,
                                        ],
                                      ),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: Column(
                                      children: [
                                        Container(
                                          height: 35,
                                          width: 400,
                                          margin: EdgeInsets.only(top: 10),
                                          child: Center(
                                            child: Text(
                                              snapShot
                                                  .data[index].rate_sell.toString(),
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 17,
                                                fontFamily: 'RobotMono',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: 35,
                                          width: 400,
                                          child: Center(
                                            child: Text(
                                              snapShot.data[index].rate_buy.toString(),
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 12,
                                                fontFamily: 'RobotMono',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: 35,
                                          width: 400,
                                          margin: EdgeInsets.only(top: 10),
                                          child: Center(
                                            child: Text(
                                              snapShot.data[index].date.toString(),
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 12,
                                                fontFamily: 'RobotMono',
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          height: 35,
                                          width: 400,
                                          margin: EdgeInsets.only(top: 10),
                                          child: Center(
                                            child: Text(
                                              snapShot.data[index].currency.toString(),
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 12,
                                                fontFamily: 'RobotMono',
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 2),
                                  ),
                                )
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
