
abstract class SignUpPageEvents extends Object {
  const SignUpPageEvents();
}

class LoadSignUpPage extends SignUpPageEvents {}
class ReloadSignUpPage extends SignUpPageEvents {}