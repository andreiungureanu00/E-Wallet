
abstract class BankInfoEvents extends Object {
  const BankInfoEvents();
}

class LoadBankInfo extends BankInfoEvents {}
class ReloadBankInfo extends BankInfoEvents {}