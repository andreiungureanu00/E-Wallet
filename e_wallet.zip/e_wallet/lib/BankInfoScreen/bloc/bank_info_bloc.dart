import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dio_http_cache/dio_http_cache.dart';
import 'package:e_wallet/BankInfoScreen/bloc/bank_info_events.dart';
import 'package:e_wallet/BankInfoScreen/bloc/bank_info_states.dart';
import 'package:e_wallet/CurrentUserSingleton/current_user_singleton.dart';
import 'package:e_wallet/models/bank.dart';
import 'package:e_wallet/models/coin.dart';
import 'package:e_wallet/models/rate.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class BankInfoBloc extends Bloc<BankInfoEvents, BankInfoStates> {
  @override
  BankInfoStates get initialState => BankInfoInit();

  Dio dio;
  Rate rate;
  List<Coin> coins;
  List<Rate> rates;
  int bankId;
  Bank bank;
  String url = "http://1df8c1182212.ngrok.io";

  // ignore: non_constant_identifier_names
  int nr_elements;
  int coinId;

  // ignore: non_constant_identifier_names
  int page_size = 20;
  String accessToken;

  BankInfoBloc(this.bank);

  getAvailableCoins() async {
    accessToken = CurrentUserSingleton().getJWT();
    Response response;
    dio = new Dio();

    coins = List();
    rates = List();
    bankId = bank.id;

    dio.interceptors.add(DioCacheManager(CacheConfig(baseUrl: "$url/banks/coin/$bankId/?format=json")).interceptor);

    response = await dio.get(
        "$url/banks/coin/$bankId/?format=json&page_size=$page_size",
        options: buildCacheOptions(Duration(days: 7),
            options: Options(headers: {
              HttpHeaders.authorizationHeader: "Bearer $accessToken"
            })));

    if (response.statusCode == 200) {
      for (var i in response.data["results"]) {
        Coin coin = Coin.fromJson(i);
        coinId = coin.id;
        dio.interceptors.add(DioCacheManager(CacheConfig(baseUrl: "$url/statistics/live/$coinId/?format=json")).interceptor);
        response = await dio.get("$url/statistics/live/$coinId/?format=json",
            options: buildCacheOptions(Duration(days: 7), maxStale: Duration(days: 10), forceRefresh: true,
                options: Options(headers: {
                  HttpHeaders.authorizationHeader: "Bearer $accessToken"
                })));

        if (response.statusCode == 200) {
          rate = Rate.fromJson(response.data[0]);
          coin.rate_sell = rate.rate_sell;
          coin.rate_buy = rate.rate_buy;
        }
        coins.add(coin);
      }
    }
  }

  @override
  Stream<BankInfoStates> mapEventToState(BankInfoEvents event) async* {
    if (event is LoadBankInfo) {
      await getAvailableCoins();
      yield BankInfoLoaded();
    }
    if (event is ReloadBankInfo) {
      yield BankInfoLoaded();
    }
  }

  loadBankInfo() {
    add(LoadBankInfo());
  }
}
