
import 'package:dio/dio.dart';
import 'package:dio_http_cache/dio_http_cache.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CurrentUserSingleton {
  String accessToken;
  String url = "http://live.curs-valutar.xyz";
  bool facebookSignIn;
  bool googleSignIn;

  static final CurrentUserSingleton _singleton =
      new CurrentUserSingleton._internal();

  factory CurrentUserSingleton() {
    return _singleton;
  }

  CurrentUserSingleton._internal();

  getAccessToken(String username, String password) async {
    Dio dio = new Dio();

    Map<String, dynamic> body = {"username": username, "password": password};

    String urlToken = "$url/users/token-obtain/";

    dio.interceptors.add(
        DioCacheManager(CacheConfig(baseUrl: "$url/users/token-obtain/"))
            .interceptor);
    var response = await dio.post(urlToken,
        data: body,
        options: buildCacheOptions(Duration(days: 7),
            maxStale: Duration(days: 10), forceRefresh: true));
    accessToken = response.data["access"].toString();
    print(accessToken);

    return accessToken;
  }

  addJWT() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('accessToken', accessToken);
  }

  addUserName(String username) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('username', username);
  }

  addPassword(String password) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('password', password);
  }

  addEmail(String email) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('email', email);
  }

  setFacebook() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('facebookSignIn', true);
    prefs.setBool('googleSignIn', false);
  }

  unsetFacebook() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('facebookSignIn', false);
  }

  setGoogle() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('googleSignIn', true);
    prefs.setBool('facebookSignIn', false);
  }

  unsetGoogle() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('googleSignIn', false);
  }

  setLogin() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('logIn', true);
  }

  unsetLogin() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('logIn', false);
  }

  addPhotoUrl(String photoUrl) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('photoUrl', photoUrl);
  }

  getFacebookSignIn() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool facebookSignIn = prefs.getBool('facebookSignIn');
    return facebookSignIn;
  }

  getGoogleSignIn() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool googleSignIn = prefs.getBool('googleSignIn');
    return googleSignIn;
  }

  getSimpleLogin() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool logIn = prefs.getBool('logIn');
    return logIn;
  }

  getUserName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String username = prefs.getString('username');
    return username;
  }

  getPassword() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String password = prefs.getString('password');
    return password;
  }

  getEmail() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String email = prefs.getString('email');
    return email;
  }

  getPhotoUrl() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String photoUrl = prefs.getString('photoUrl');
    return photoUrl;
  }

  getJWT() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String jwt = prefs.getString('accessToken');
    return jwt;
  }

  removeJWT() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove("accessToken");
  }

  removeCredentials() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove("photoUrl");
    prefs.remove("username");
    prefs.remove("password");
    prefs.remove("email");
  }

  containsJWT() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool checkValue = prefs.containsKey('accessToken');

    return checkValue;
  }
}
