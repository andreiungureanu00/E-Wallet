import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dio_http_cache/dio_http_cache.dart';
import 'package:e_wallet/BankPageScreen/bloc/bank_page_events.dart';
import 'package:e_wallet/BankPageScreen/bloc/bank_page_states.dart';
import 'package:e_wallet/CurrentUserSingleton/current_user_singleton.dart';
import 'package:e_wallet/models/bank.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class BankPageBloc extends Bloc<BankPageEvents, BankPageStates> {
  @override
  BankPageStates get initialState => BankPageInit();
  List<Bank> banks;
  String url = "http://live.curs-valutar.xyz";
  String accessToken;


  getBanks() async {
    Response response;
    banks = List();
    Dio dio = new Dio();
    dio.interceptors.add(
        DioCacheManager(CacheConfig(baseUrl: "$url/banks/bank/?format=json"))
            .interceptor);
    response = await dio.get("$url/banks/bank/?format=json",
        options: buildCacheOptions(Duration(days: 7), maxStale: Duration(days: 10), forceRefresh: true,
            options: Options(headers: {
              HttpHeaders.authorizationHeader: "Bearer $accessToken"
            })));

    print(response.data.toString());

    for (var i in response.data["results"]) {
      Bank bank = Bank.fromJson(i);
      banks.add(bank);
    }
  }

  @override
  Stream<BankPageStates> mapEventToState(BankPageEvents event) async* {
    if (event is LoadBankPage) {
      accessToken = await CurrentUserSingleton().getAccessToken("testuser", "testuser");
      await getBanks();
      yield BankPageLoaded();
    }
    if (event is ReloadBankPage) {
      yield BankPageLoaded();
    }
  }

  loadBanks() {
    add(LoadBankPage());
  }
}
