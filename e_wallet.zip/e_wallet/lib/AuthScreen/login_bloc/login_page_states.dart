abstract class LoginPageStates extends Object {
  const LoginPageStates();
}

class LoginPageInit extends LoginPageStates {}
class LoginPageLoaded extends LoginPageStates {}
class LoginPageReloaded extends LoginPageStates {}