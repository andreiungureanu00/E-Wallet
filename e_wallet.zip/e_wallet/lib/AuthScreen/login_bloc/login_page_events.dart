
abstract class LoginPageEvents extends Object {
  const LoginPageEvents();
}

class LoadLoginPage extends LoginPageEvents {}
class ReloadLoginPage extends LoginPageEvents {}