abstract class MainScreenState extends Object {
  const MainScreenState();
}

class WalletsInit extends MainScreenState {}
class WalletsLoaded extends MainScreenState {}
class WalletsReloaded extends MainScreenState {}