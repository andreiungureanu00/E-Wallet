import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dio_http_cache/dio_http_cache.dart';
import 'package:e_wallet/CurrentUserSingleton/current_user_singleton.dart';
import 'package:e_wallet/MainScreen/bloc/main_screen_state.dart';
import 'package:e_wallet/models/coin.dart';
import 'package:e_wallet/models/wallet.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'main_screen_event.dart';

class MainScreenBloc extends Bloc<MainScreenEvent, MainScreenState> {
  @override
  MainScreenState get initialState => WalletsInit();

  String url = "http://live.curs-valutar.xyz";
  String accessToken;
  List<Wallet> wallets;
  Dio dio;
  String coinName;

  getWallets() async {
    var response;
    wallets = List();
    dio = new Dio();

    dio.interceptors.add(
        DioCacheManager(CacheConfig(baseUrl: "$url/wallets/")).interceptor);

    response = await dio.get("$url/wallets/",
        options: buildCacheOptions(Duration(days: 7),
            maxStale: Duration(days: 10),
            forceRefresh: true,
            options: Options(headers: {
              HttpHeaders.authorizationHeader: "Bearer $accessToken"
            })));

    print(accessToken);
    for (var i in response.data) {
      Wallet wallet = Wallet.fromJson(i);
      wallet.currencyName = await getCurrencyById(wallet.currency);
      wallets.add(wallet);
    }
  }

  getCurrencyById(int currencyId) async {
    coinName = "";

    dio.interceptors.add(DioCacheManager(
            CacheConfig(baseUrl: "$url/banks/coin/?format=json&page_size=20"))
        .interceptor);
    Response response = await dio.get(
        "$url/banks/coin/?format=json&page_size=20",
        options: buildCacheOptions(Duration(days: 7),
            maxStale: Duration(days: 10),
            forceRefresh: true,
            options: Options(headers: {
              HttpHeaders.authorizationHeader: "Bearer $accessToken"
            })));

    for (var i in response.data["results"]) {
      Coin coin = Coin.fromJson(i);
      if (coin.id == currencyId) coinName = coin.abbr;
    }

    return coinName;
  }

  @override
  Stream<MainScreenState> mapEventToState(MainScreenEvent event) async* {
    if (event is LoadWallets) {
      accessToken =
          await CurrentUserSingleton().getAccessToken("testuser", "testuser");
      print(accessToken);
      await getWallets();
      yield WalletsLoaded();
    }
    if (event is ReloadWallets) {
      yield WalletsLoaded();
    }
  }

  loadWallets() {
    add(LoadWallets());
  }
}
