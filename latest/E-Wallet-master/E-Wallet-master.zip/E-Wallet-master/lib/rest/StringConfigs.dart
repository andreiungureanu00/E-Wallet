
class StringConfigs{
  static const String baseApiUrl = "https://live.curs-valutar.xyz";
}