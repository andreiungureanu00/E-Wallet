abstract class SignUpPageStates extends Object {
  const SignUpPageStates();
}

class SignUpPageInit extends SignUpPageStates {}

class SignUpPageLoaded extends SignUpPageStates {}

class SignUpPageReloaded extends SignUpPageStates {}
