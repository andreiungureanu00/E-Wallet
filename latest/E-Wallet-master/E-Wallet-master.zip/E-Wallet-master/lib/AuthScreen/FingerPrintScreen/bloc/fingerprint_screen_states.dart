abstract class FingerPrintScreenStates extends Object {
  const FingerPrintScreenStates();
}

class FingerPrintScreenInit extends FingerPrintScreenStates {}
class FingerPrintScreenLoaded extends FingerPrintScreenStates {}
class FingerPrintScreenReloaded extends FingerPrintScreenStates {}