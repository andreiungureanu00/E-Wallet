abstract class NetworkIndicatorStates extends Object {
  const NetworkIndicatorStates();
}

class Shown extends NetworkIndicatorStates {}
class Loading extends NetworkIndicatorStates {}
class Hidden extends NetworkIndicatorStates {}