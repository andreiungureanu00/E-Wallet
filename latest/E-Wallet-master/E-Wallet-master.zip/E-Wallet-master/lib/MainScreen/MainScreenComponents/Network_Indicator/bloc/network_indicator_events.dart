
abstract class NetworkIndicatorEvents extends Object {
  const NetworkIndicatorEvents();
}

class ShowNetworkIndicator extends NetworkIndicatorEvents {}
class HideNetworkIndicator extends NetworkIndicatorEvents {}
class ReloadIndicator extends NetworkIndicatorEvents {}