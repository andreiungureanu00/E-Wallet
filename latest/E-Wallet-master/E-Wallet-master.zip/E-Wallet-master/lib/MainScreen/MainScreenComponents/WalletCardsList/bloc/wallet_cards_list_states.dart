abstract class WalletCardsListStates extends Object {
  const WalletCardsListStates();
}

class WalletsInit extends WalletCardsListStates {}
class WalletsLoaded extends WalletCardsListStates {}
class WalletsReloaded extends WalletCardsListStates {}